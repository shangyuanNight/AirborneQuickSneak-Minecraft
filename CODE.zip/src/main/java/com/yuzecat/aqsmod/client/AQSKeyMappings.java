package com.yuzecat.aqsmod.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.yuzecat.aqsmod.AQSMod;
import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.settings.KeyConflictContext;
import net.neoforged.neoforge.client.settings.KeyModifier;
import org.lwjgl.glfw.GLFW;

@EventBusSubscriber(modid = AQSMod.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class AQSKeyMappings {

    public static final String KEY_CATEGORY = "key.categories.aqsmod";

    public static KeyMapping toggleSneakKey;
    public static KeyMapping toggleSpeedKey;
    public static KeyMapping openSettingsKey;

    @SubscribeEvent
    public static void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
        // Alt + 空格：切换空中潜行
        toggleSneakKey = new KeyMapping(
            "key.aqsmod.toggle_sneak",
            KeyConflictContext.IN_GAME,
            KeyModifier.ALT,
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_SPACE,
            KEY_CATEGORY
        );
        event.register(toggleSneakKey);

        // Alt + 退格：循环切换速度
        toggleSpeedKey = new KeyMapping(
            "key.aqsmod.toggle_speed",
            KeyConflictContext.IN_GAME,
            KeyModifier.ALT,
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_BACKSPACE,
            KEY_CATEGORY
        );
        event.register(toggleSpeedKey);

        // Alt + `：打开设置
        openSettingsKey = new KeyMapping(
            "key.aqsmod.open_settings",
            KeyConflictContext.IN_GAME,
            KeyModifier.ALT,
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_GRAVE_ACCENT,
            KEY_CATEGORY
        );
        event.register(openSettingsKey);
    }
}