package com.yuzecat.aqsmod.client.screen;

import com.yuzecat.aqsmod.client.AQSClientEvents;
import com.yuzecat.aqsmod.client.AQSModState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;

public class AQSSettingsScreen extends Screen {

    private Button modToggleBtn;
    private Button sneakToggleBtn;
    private Button speedCycleBtn;

    public AQSSettingsScreen() {
        super(Component.translatable("screen.aqsmod.settings"));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int btnW = 180;
        int btnH = 20;
        int gap = 4;
        // 按钮组整体压到屏幕最下方，紧邻"完成"按钮上方
        int startY = this.height - 100;

        // ① 模组总开关
        modToggleBtn = Button.builder(
            getModButtonText(),
            btn -> {
                AQSModState.toggleModEnabled();
                btn.setMessage(getModButtonText());
            }
        ).bounds(centerX - btnW / 2, startY, btnW, btnH).build();
        this.addRenderableWidget(modToggleBtn);

        // ② 空中潜行开关
        sneakToggleBtn = Button.builder(
            getSneakButtonText(),
            btn -> {
                AQSModState.toggleAirborneSneak();
                btn.setMessage(getSneakButtonText());
            }
        ).bounds(centerX - btnW / 2, startY + btnH + gap, btnW, btnH).build();
        this.addRenderableWidget(sneakToggleBtn);

        // ③ 速度模式切换
        speedCycleBtn = Button.builder(
            getSpeedButtonText(),
            btn -> {
                AQSModState.cycleSpeedMode();
                btn.setMessage(getSpeedButtonText());
                Minecraft mc = Minecraft.getInstance();
                if (mc.player != null) {
                    AQSClientEvents.applySpeedMode(mc.player);
                }
            }
        ).bounds(centerX - btnW / 2, startY + (btnH + gap) * 2, btnW, btnH).build();
        this.addRenderableWidget(speedCycleBtn);

        // ④ 完成按钮
        this.addRenderableWidget(Button.builder(
            CommonComponents.GUI_DONE,
            button -> this.minecraft.setScreen(null)
        ).bounds(centerX - 50, this.height - 26, 100, 20).build());
    }

    @Override
    public void tick() {
        super.tick();
        if (modToggleBtn != null) modToggleBtn.setMessage(getModButtonText());
        if (sneakToggleBtn != null) sneakToggleBtn.setMessage(getSneakButtonText());
        if (speedCycleBtn != null) speedCycleBtn.setMessage(getSpeedButtonText());
    }

    private Component getModButtonText() {
        String key = AQSModState.isModEnabled()
            ? "screen.aqsmod.mod.enabled"
            : "screen.aqsmod.mod.disabled";
        return Component.translatable("screen.aqsmod.mod", Component.translatable(key));
    }

    private Component getSneakButtonText() {
        String key = AQSModState.isAirborneSneakActive()
            ? "screen.aqsmod.sneak.on"
            : "screen.aqsmod.sneak.off";
        return Component.translatable("screen.aqsmod.sneak", Component.translatable(key));
    }

    private Component getSpeedButtonText() {
        String key = switch (AQSModState.getCurrentSpeedMode()) {
            case FLYING -> "hud.aqsmod.speed.flying";
            case FLYING_SPRINT -> "hud.aqsmod.speed.flying_sprint";
            case WALKING -> "hud.aqsmod.speed.walking";
            case WALKING_SPRINT -> "hud.aqsmod.speed.walking_sprint";
        };
        return Component.translatable("screen.aqsmod.speed", Component.translatable(key));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics, mouseX, mouseY, partialTick);

        int centerX = this.width / 2;

        // ===== 顶部信息区：紧凑排列，行距压缩 =====
        int y = 20;

        // 标题
        graphics.drawCenteredString(this.font, "Airborne Quick Sneak", centerX, y, 0xFFFFFF);
        y += 14;

        // 版本（紧贴标题下方）
        graphics.drawCenteredString(this.font, "v1.0.0", centerX, y, 0xAAAAAA);
        y += 14;

        // 作者
        graphics.drawCenteredString(this.font, "Author: YuzeCat", centerX, y, 0xFFFFFF);
        y += 12;

        // GitHub 链接
        graphics.drawCenteredString(this.font, "https://github.com/shangyuanNight", centerX, y, 0x8888FF);
        y += 12;

        // 协议
        graphics.drawCenteredString(this.font, "License: CC BY-NC 4.0", centerX, y, 0xAAAAAA);

        // 按钮由 super.render 渲染
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}