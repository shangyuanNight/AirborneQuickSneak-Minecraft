package com.yuzecat.aqsmod.util;

import net.minecraft.world.entity.player.Player;

public class AirborneUtil {
    
    /**
     * 判断玩家是否处于空中（非地面、非水中、非岩浆中）
     */
    public static boolean isInAir(Player player) {
        return !player.onGround() 
            && !player.isInWater() 
            && !player.isInLava();
    }
}