package com.yuzecat.aqsmod.mixin;

import com.yuzecat.aqsmod.client.AQSModState;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class PlayerShiftMixin {

    @Inject(
        method = "isShiftKeyDown()Z",
        at = @At("HEAD"),
        remap = false,
        cancellable = true
    )
    private void onIsShiftKeyDown(CallbackInfoReturnable<Boolean> cir) {
        Entity self = (Entity) (Object) this;
        if (!(self instanceof Player)) return;
        if (AQSModState.isAirborneSneakActive() && !self.onGround()) {
            cir.setReturnValue(true);
        }
    }
}