package com.yuzecat.aqsmod.mixin;

import com.yuzecat.aqsmod.client.AQSModState;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class PlayerHitboxMixin {

    @Inject(
        method = "getDimensions(Lnet/minecraft/world/entity/Pose;)Lnet/minecraft/world/entity/EntityDimensions;",
        at = @At("HEAD"),
        remap = false,
        cancellable = true
    )
    private void onGetDimensions(Pose pose, CallbackInfoReturnable<EntityDimensions> cir) {
        Entity self = (Entity) (Object) this;
        if (!(self instanceof Player)) return;
        if (AQSModState.isAirborneSneakActive() && !self.onGround()) {
            cir.setReturnValue(EntityDimensions.scalable(0.6F, 1.5F));
        }
    }
}