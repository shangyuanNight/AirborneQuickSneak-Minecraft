package com.yuzecat.aqsmod.client;

import com.yuzecat.aqsmod.AQSMod;
import com.yuzecat.aqsmod.client.screen.AQSSettingsScreen;
import com.yuzecat.aqsmod.util.AirborneUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

@EventBusSubscriber(modid = AQSMod.MOD_ID, value = Dist.CLIENT)
public class AQSClientEvents {

    private static final float VANILLA_FLYING_SPEED = 0.05F;

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null) return;

        // Alt + `：打开设置（任意位置，不受模组开关影响）
        while (AQSKeyMappings.openSettingsKey.consumeClick()) {
            mc.setScreen(new AQSSettingsScreen());
        }

        // 模组总开关关闭时：立即恢复原版
        if (!AQSModState.isModEnabled()) {
            restoreVanillaSpeeds(player);
            player.setShiftKeyDown(false);
            return;
        }

        boolean inAir = AirborneUtil.isInAir(player);

        if (inAir) {
            handleAirborneInput(player);
            applySpeedMode(player);
        } else {
            restoreVanillaSpeeds(player);
            AQSModState.reset();
            player.setShiftKeyDown(false);
        }

        if (AQSModState.isAirborneSneakActive() && inAir) {
            player.setShiftKeyDown(true);
        }
    }

    private static void handleAirborneInput(LocalPlayer player) {
        while (AQSKeyMappings.toggleSneakKey.consumeClick()) {
            AQSModState.toggleAirborneSneak();
        }
        while (AQSKeyMappings.toggleSpeedKey.consumeClick()) {
            AQSModState.cycleSpeedMode();
            applySpeedMode(player);
        }
    }

    /** 根据当前速度模式应用实际速度（public 供设置界面调用） */
    public static void applySpeedMode(LocalPlayer player) {
        float speed = switch (AQSModState.getCurrentSpeedMode()) {
            case FLYING -> VANILLA_FLYING_SPEED;
            case FLYING_SPRINT -> VANILLA_FLYING_SPEED * 2.0F;
            case WALKING -> 0.02F;
            case WALKING_SPRINT -> 0.03F;
        };
        player.getAbilities().setFlyingSpeed(speed);
    }

    /** 恢复原版 */
    public static void restoreVanillaSpeeds(LocalPlayer player) {
        player.getAbilities().setFlyingSpeed(VANILLA_FLYING_SPEED);
    }
}