package com.yuzecat.aqsmod;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;

@Mod(AQSMod.MOD_ID)
public class AQSMod {
    public static final String MOD_ID = "aqsmod";
    
    public AQSMod(IEventBus modEventBus, ModContainer modContainer) {
        // 客户端事件由 @EventBusSubscriber 自动注册
    }
}