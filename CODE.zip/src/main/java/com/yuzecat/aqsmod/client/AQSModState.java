package com.yuzecat.aqsmod.client;

public class AQSModState {

    /** 四种速度模式 */
    public enum SpeedMode {
        FLYING,          // 飞行速度
        FLYING_SPRINT,   // 飞行冲刺速度
        WALKING,         // 地面行走速度
        WALKING_SPRINT   // 地面冲刺速度
    }

    /** 模组总开关 */
    private static boolean modEnabled = true;

    private static boolean airborneSneakActive = false;
    private static SpeedMode currentSpeedMode = SpeedMode.FLYING;

    // ========== 模组总开关 ==========
    public static boolean isModEnabled() { return modEnabled; }
    public static void toggleModEnabled() { modEnabled = !modEnabled; }
    public static void setModEnabled(boolean enabled) { modEnabled = enabled; }

    // ========== 潜行状态 ==========
    public static boolean isAirborneSneakActive() { return airborneSneakActive; }
    public static void toggleAirborneSneak() { airborneSneakActive = !airborneSneakActive; }
    public static void setAirborneSneakActive(boolean active) { airborneSneakActive = active; }

    // ========== 速度模式 ==========
    public static SpeedMode getCurrentSpeedMode() { return currentSpeedMode; }
    public static void setSpeedMode(SpeedMode mode) { currentSpeedMode = mode; }

    /** 循环切换 4 种速度模式 */
    public static void cycleSpeedMode() {
        currentSpeedMode = switch (currentSpeedMode) {
            case FLYING -> SpeedMode.FLYING_SPRINT;
            case FLYING_SPRINT -> SpeedMode.WALKING;
            case WALKING -> SpeedMode.WALKING_SPRINT;
            case WALKING_SPRINT -> SpeedMode.FLYING;
        };
    }

    // ========== 重置 ==========
    public static void reset() {
        airborneSneakActive = false;
        currentSpeedMode = SpeedMode.FLYING;
        // 不重置 modEnabled，让总开关跨世界保持
    }

    public static boolean isAnyActive() { return airborneSneakActive; }
}