package com.yuzecat.aqsmod.client.hud;

import com.yuzecat.aqsmod.AQSMod;
import com.yuzecat.aqsmod.client.AQSModState;
import com.yuzecat.aqsmod.util.AirborneUtil;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;

@EventBusSubscriber(modid = AQSMod.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class AQSHudLayer {

    @SubscribeEvent
    public static void onRegisterGuiLayers(RegisterGuiLayersEvent event) {
        event.registerAboveAll(
            ResourceLocation.fromNamespaceAndPath(AQSMod.MOD_ID, "aqs_hud"),
            AQSHudLayer::render
        );
    }

    public static void render(GuiGraphics graphics, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;

        if (player == null || mc.options.hideGui) return;
        if (!AirborneUtil.isInAir(player)) return;
        if (!AQSModState.isAnyActive()) return;

        int x = 10;
        int y = 10;
        int lineHeight = 12;

        // 潜行提示
        if (AQSModState.isAirborneSneakActive()) {
            Component sneakText = Component.translatable("hud.aqsmod.airborne_sneaking");
            graphics.drawString(mc.font, sneakText, x, y, 0xFFFFFF00, true);
            y += lineHeight;
        }

        // 速度提示（4 种模式）
        Component speedText = switch (AQSModState.getCurrentSpeedMode()) {
            case FLYING -> Component.translatable("hud.aqsmod.speed.flying");
            case FLYING_SPRINT -> Component.translatable("hud.aqsmod.speed.flying_sprint");
            case WALKING -> Component.translatable("hud.aqsmod.speed.walking");
            case WALKING_SPRINT -> Component.translatable("hud.aqsmod.speed.walking_sprint");
        };
        graphics.drawString(mc.font, speedText, x, y, 0xFF00FFFF, true);
    }
}